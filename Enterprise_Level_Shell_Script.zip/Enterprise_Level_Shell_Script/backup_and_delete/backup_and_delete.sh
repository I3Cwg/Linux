#!/bin/bash

backup_and_delete() {

	# Check for the number of files in the to_backup directory
	num_files_to_move=$(ls -l ${to_backup_dir}/*.txt | wc -l)

	if [[ $num_files_to_move -eq 0 ]]; then

		log "Exiting process. No files to move"
		exit
	fi

	log "Starting backup and delete process"	

	#Move the files to the backup dir from to_backup
	mv ${to_backup_dir}/*.txt ${backup_dir}/

	#Check for the number of files that actually moved
	num_files_moved=$(ls -l ${backup_dir}/*.txt | wc -l)
	
	#Check for success or failure
	if [[ $num_files_to_move = $num_files_moved ]]; then

		log "Files successfully backed up"
	else	

		log "Failure backing up files"
	fi

	if rm -f ${backup_dir}/tmp/*.txt; then

		if rm -rf ${backup_dir}/tmp; then

			log "tmp directory successfully deleted"

		else

			log "Failed deleting tmp directory"
		fi
	fi

	log "Completed backup and delete process"	
}
