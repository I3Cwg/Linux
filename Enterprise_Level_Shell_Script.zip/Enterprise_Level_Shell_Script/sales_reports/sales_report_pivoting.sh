#!/bin/bash

sales_report_pivoting(){

	awk -F '|' \
		'NR>1 {departments[$2]} \
		 $1 == "ABC" {abc_sales[$2]=$3} \
		 $1 == "CDE" {cde_sales[$2]=$3} \
		 $1 == "XYZ" {xyz_sales[$2]=$3} \
		 END { \
			printf "Department|ABC|CDE|XYZ\n"; \
			for (dept in departments) \
				printf "%s|%s|%s|%s\n", dept, abc_sales[dept], cde_sales[dept], xyz_sales[dept] \
		}' ${sales_pivot_csv} >> ${sales_pivot_rpt}
		
}
