#!/bin/bash

sales_report_aggregation() {

echo -e "\n***Aggregate Totals by month per item" >> ${sales_agg_rpt}

#Aggregate totals by month per item
awk -F '|' 'BEGIN {OFS="|"; } \
			NR>1 {salesJan[$1]+=$2;salesFeb[$1]+=$3;salesMar[$1]+=$4; next} \
			END{print "ItemId|Jan Totals|Feb Totals|Mar Totals"; \
			for (item in salesJan) print item,salesJan[item],salesFeb[item],salesMar[item] | "$1 sort"; }' 			${sales_agg_csv} >> ${sales_agg_rpt}

echo -e "\n***Aggregate Totals per item" >> ${sales_agg_rpt}

awk -F '|' 'BEGIN {OFS="|"; } \
			NR>1 {salesJan[$1]+=$2;salesFeb[$1]+=$3;salesMar[$1]+=$4; next} \
			END{print "ItemId|Totals"; \
			for (item in salesJan) print item,salesJan[item]+salesFeb[item]+salesMar[item] | "$1 sort"; }' 			${sales_agg_csv} >> ${sales_agg_rpt}

echo -e "\n***Aggregate Counts per item" >> ${sales_agg_rpt}

#Aggregate counts by item
awk -F '|' 'BEGIN {OFS="|"; } \
			NR>1 {salesJan[$1]++; next} \
			END{print "ItemId|Counts"; \
			for (item in salesJan) print item,salesJan[item] | "$1 sort"; }'	${sales_agg_csv} >> ${sales_agg_rpt}

echo -e "\n***Average Totals per month per item" >> ${sales_agg_rpt}

#Average totals by month by item
awk -F '|' 'BEGIN {OFS="|"; } \
			NR>1 {salesJan[$1]+=$2;salesFeb[$1]+=$3;salesMar[$1]+=$4; count[$1]++; next} \
			END{print "ItemId|Jan Total|Feb Total|Mar Total"; \
			for (item in salesJan) print item,salesJan[item]/count[item],salesFeb[item]/count[item],salesMar[item]/count[item] | "$1 sort"; }' 			${sales_agg_csv} >> ${sales_agg_rpt}

echo -e "\n***Average Totals per item" >> ${sales_agg_rpt}

#Average totals by item
awk -F '|' 'BEGIN {OFS="|"; } \
			NR>1 {salesJan[$1]+=$2;salesFeb[$1]+=$3;salesMar[$1]+=$4; count[$1]++; next} \
			END{print "ItemId|Total Avg"; \
			for (item in salesJan) print item,(salesJan[item]+salesFeb[item]+salesMar[item])/count[item] | "$1 sort"; }' 			${sales_agg_csv} >> ${sales_agg_rpt}
}
