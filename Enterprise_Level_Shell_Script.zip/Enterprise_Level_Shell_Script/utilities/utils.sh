#!/bin/bash

report_compression(){

	log "*****Starting compression"

	find ${home_dir}/scripts -name "*.rpt" | while read file
	do
		log "Processing file: " $file
		tar -Pzcf ${file}.tar.gz ${file}
	done	

	log "*****Completed compression"
}

report_copy(){

	log "Starting copy process"

	find ${home_dir}/scripts -type f -name "*.rpt" -exec dirname "{}" \; | sort -u | while read dir
	do

		find ${dir} -name '*.tar.gz' -not -path "${dir}/*backup*" | while read file
		do

			if [[ ! -d ${dir}/backup ]]; then

				mkdir -p ${dir}/backup >/dev/null
			fi

			log "Copying ${file} to ${dir}/backup"
			cp $file ${dir}/backup/ >/dev/null
		done
	done	

	log "Completed copy process"
}
