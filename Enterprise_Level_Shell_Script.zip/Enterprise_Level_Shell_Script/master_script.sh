# Author: Arshad Syed
# Date: 07/08/2023
# Description: This script delivers the following reports
#			   - Merging of documents with templates
#              - Listing of Users and Groups
#              - Sales Reports - Aggregation, Pivoting and Formatting
#              - Monitoring Report - Hard Disk utilization with Alert
#              - File Backup and deleting old files
#              - Tabular report demonstrating Cut, Sort and Uniq
#              - Report demonstrating Search and Replace using Sed
# 			   - Report demonstrating filter and formatting
#              - Provide compression for Report files
#              - Copy reports to directories specified in input file

home_dir=/home/syedaf
config_file=/${home_dir}/scripts/config/config.txt
local_functions=${home_dir}/scripts/lib/local_functions.sh
disk_monitor=${home_dir}/scripts/disk_monitor/disk_monitor.sh
doc_merge=${home_dir}/scripts/doc_merge/document_merge.sh
users_groups=${home_dir}/scripts/users_and_groups/list_users_and_groups.sh
sales_report_aggregation=${home_dir}/scripts/sales_reports/sales_report_aggregation.sh
sales_report_pivoting=${home_dir}/scripts/sales_reports/sales_report_pivoting.sh
backup_and_delete=${home_dir}/scripts/backup_and_delete/backup_and_delete.sh
search_and_replace=${home_dir}/scripts/search_and_replace/search_and_replace.sh
filter_and_format=${home_dir}/scripts/filter_and_format/filter_and_format.sh
utilities=${home_dir}/scripts/utilities/utils.sh

source ${config_file}
source ${local_functions}
source ${doc_merge}
source ${users_groups}
source ${sales_report_aggregation}
source ${sales_report_pivoting}
source ${disk_monitor}
source ${backup_and_delete}
source ${search_and_replace}
source ${filter_and_format}
source ${utilities}

logging=true
init_logs_and_reports

current_date=$(date +%Y%m%d)
log "Current date: $current_date"
start_time=$(date +%H%M%S)
log "Start time: $start_time"

user=$(whoami)
log "User: ${user}"

arg_list="${@}"
log "Argument list: ${arg_list}"

usage(){

	echo -e "Sample usage: ${0} -l<Y/N> -d<report_date> -t -r"
	echo -e "\t-l specifies the logging option. Specify Y or N"
	echo -e "\t-d specifies the date option"
	echo -e "\t-t specifies the trim option to be run on some documents"
	echo -e "\t-r specifies the entire set of reports needs to be run"

	exit 1
}

######################################Main Processing#############################

if [ $# -ne 0 ]; then

	while getopts "l:d:tr" optName; do

		case ${optName} in 

			l)

				if [[ ${OPTARG} == "Y" ]]; then
					logging=true
				else
					logging=false
				fi
			;;
			d)
				
				report_date=${OPTARG}
				validate_date ${report_date}
				log "Reports run date: ${report_date}"
			;;
			t)

				delete_empty_lines_and_comments ${cleanup_dir}
			;;
			r)

				document_merge
				list_users_groups
				sales_report_aggregation
				sales_report_pivoting
				disk_monitor
				backup_and_delete
				search_and_replace
				filter_and_format
			;;
			:) # expected argument missing

				log_tee "Error: argument missing"
				log_tee "Incorrect usage: $(usage)"
				cleanup_and_exit 1
			;;
		esac
	done

	shift $((OPTIND-1))

	#Compress reports
	report_compression

	#Copy compressed reports to output directory
	report_copy

else

	echo "Usage: $(usage)"
	cleanup_and_exit 1
fi
