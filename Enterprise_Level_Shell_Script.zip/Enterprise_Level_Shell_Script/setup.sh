#!/bin/bash

# Setup for delete blank lines and comments
cp cleanup_dir/template.txt cleanup_dir/cleanup_1.txt
cp cleanup_dir/template.txt cleanup_dir/cleanup_2.txt

# Setup for hard disk monitoring
fallocate -l $((5*1024*1024)) disk_monitor/disk_monitor.txt

# Setup for backup process
mv /home/syedaf/scripts/backup_and_delete/backup/*.txt /home/syedaf/scripts/backup_and_delete/to_backup/

# Setup for delete process
mkdir -p /home/syedaf/scripts/backup_and_delete/backup/tmp
touch /home/syedaf/scripts/backup_and_delete/backup/tmp/del_{0..9}.txt



