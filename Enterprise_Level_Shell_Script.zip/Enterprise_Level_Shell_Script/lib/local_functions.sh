#!/bin/bash

config_file=${home_dir}/scripts/config/config.txt
source ${config_file}

cleanup_and_exit() {

	exit $1
}

delete_empty_lines_and_comments() {

	for file in $1/cleanup_*.txt
	do
		sed -i -e '/^[[:space:]]*$/d' -e '/^#/d' $file
		log "Cleaned up file: $file"
	done
}

init_logs_and_reports() {

	echo -n "" > ${log_file}
	echo -n "" > ${users_groups_rpt}
	echo -n "" > ${sales_agg_rpt}
	echo -n "" > ${sales_pivot_rpt}
	echo -n "" > ${filter_format_rpt}
}

log() {

	[[ ${logging} = true ]] && echo -e "${@}\n" 2>&1 >> ${log_file}
}

log_tee() {

	[[ ${logging} = true ]] && echo -e "${@}\n" | tee  2>&1 >> ${log_file}
}

users_groups_report(){

	echo -e "${@}\n" 2>&1 >> ${users_groups_rpt}
}

validate_date() {

	regexp="^[0-9]{4}-[0-9]{2}-[0-9]{2}$"

	[[ $1 =~ ${regexp} ]] && date "+%Y-%m-%d" -d $1 >/dev/null 2>&1
	if [[ $? = 1 ]]; then

		echo "Invalid date. Enter valid date in the format YYYY-MM-DD"

		usage
	
		cleanup_and_exit 1
	fi
}
