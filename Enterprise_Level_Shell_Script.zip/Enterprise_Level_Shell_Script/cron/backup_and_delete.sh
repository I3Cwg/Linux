#!/bin/bash

CURR_DIR=/home/syedaf/test_scripts/cron
LOGFILE=${CURR_DIR}/backup_delete_log.txt

# Check for the number of files in the to_backup directory
num_files_to_move=$(ls -l ${CURR_DIR}/to_backup/*.txt | wc -l)

if [[ $num_files_to_move -eq 0 ]]; then

	exit
fi

echo -n "" > ${LOGFILE}

echo "Starting backup and delete " >> ${LOGFILE}

# Move the files to the backup directory
mv ${CURR_DIR}/to_backup/*.txt ${CURR_DIR}/backup/

# Check for the number of files actually moved
num_files_moved=$(ls -l ${CURR_DIR}/backup/*.txt | wc -l)

# Check for success or failure
if [[ $num_files_to_move = $num_files_moved ]]; then

	echo "Files successfully backed up " >> ${LOGFILE}
else 

	echo "Failure backing up files " >> ${LOGFILE}
fi

# Delete the files in the tmp directory and the directory itself
if rm -f ${CURR_DIR}/tmp/*.txt; then

	if rm -rf ${CURR_DIR}/tmp; then

		echo "tmp directory successfully deleted" >> ${LOGFILE}
	else
	
		echo "failed deleting tmp directory " >> ${LOGFILE}
	fi
fi


