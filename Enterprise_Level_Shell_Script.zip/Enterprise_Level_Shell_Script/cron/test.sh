#bin/bash

echo "test" >> ./backup/test.out
