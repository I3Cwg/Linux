#!/bin/bash

list_users_groups(){

conf_file=${users_and_groups_dir}/groups.conf

for groupFile in ${users_and_groups_dir}/*.group
do
	server=$(basename $groupFile ".group")

	users_groups_report "*************************"

	users_groups_report "Processing group file ${groupFile} for server: ${server}"

	users_groups_report "*************************"

	users_groups_report "Listing Users and their Groups"

	grep -wf ${conf_file} ${groupFile} | awk -F: '{print $1, $3, $4}' | while IFS=' ' read group groupId members
	do
		users_groups_report "${group}: $members"
	done
	
done

}
