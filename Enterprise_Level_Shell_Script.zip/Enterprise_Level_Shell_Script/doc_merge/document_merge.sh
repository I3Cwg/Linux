#!/bin/bash

document_merge(){

log "##############################Document Merge Process###############################"

IFS=","

start_time=$(date '+%d-%m-%Y %H%M%S')
log "Starting document merge process at ${start_time}"

while read -r lastName firstName # Customer Name
do

	while read -r eventName beginDate endDate minPct maxPct # Specials Information
	do

		sed -e "s/<First_Name>/${firstName}/g" \
			-e "s/<Last_Name>/${lastName}/g" \
			-e "s/<Holiday_Specials>/${eventName}/g" \
			-e "s/<Begin_Date>/${beginDate}/g" \
			-e "s/<End_Date>/${endDate}/g" \
			-e "s/<Min_Pct>/${minPct}/g" \
			-e "s/<Max_Pct>/${maxPct}/g" ${doc_merge_template_file} > ${doc_merge_dir}/reports/${firstName}_${lastName}_${eventName}.txt

	done < ${doc_merge_conf_file}

done < ${doc_merge_customer_file}

end_time=$(date '+%d-%m-%Y %H%M%S')
log "Completed document merge process at ${end_time}"
}
