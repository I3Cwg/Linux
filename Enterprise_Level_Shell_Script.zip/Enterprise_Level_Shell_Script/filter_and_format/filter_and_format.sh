#!/bin/bash

filter_and_format(){

log "Starting filter and format report"

#Filter and get the rows with totals > 80000
#Format the output report

awk -F',' \
	'BEGIN {print "--------------------------------" 
			printf "%-20s %-6s\n", "User", "Total" 
			print "--------------------------------"} \
	$2 >= 80000 {printf "%-20s %-6s\n", $1, $2}' ${filter_format_csv} | (sed -u 3q; sort -k1) >> ${filter_format_rpt}

log "Completed filter and format report"
}
