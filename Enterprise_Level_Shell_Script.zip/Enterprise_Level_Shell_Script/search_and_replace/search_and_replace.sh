#!/bin/bash

search_and_replace(){

log "Starting search and replace"

sed -e 's/\([0-9]\{3\}\)-\([0-9]\{3\}-[0-9]\{4\}\)/(\1)\2/g' ${search_and_replace_input} >> ${search_and_replace_output}

log "Completed search and replace"
}
