#!/bin/bash

threshold_size=4000000

disk_monitor(){

log "####################Starting disk monitoring process"

file_size=$(ls -l ${disk_monitor_file} | awk '{print $5}')

log "File size is: $file_size"

if [[ $file_size > $threshold_size ]]; then

	log "Deleting file: " ${disk_monitor_file}
	rm -f ${disk_monitor_file}
fi

[[ ! -f ${disk_monitor_file} ]] && log "${disk_monitor_file} successfully deleted" || log "${disk_monitor_file} exists"

log "Completed disk monitoring process"
}
