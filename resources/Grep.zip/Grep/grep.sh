#!/bin/bash

if grep -q "doctor" grep.csv; then

	echo "success"
else

	echo "failure"
fi

i=0
grep "doctor" grep.csv | while read a;
do
	((i++))
	echo "Line number: $i"
done
