#!/bin/bash

<<'###ARGC' # ARGC & ARGV Usage
	
	awk 'BEGIN { print "Number of args =", ARGC;
				print "ARGV[0] = " ARGV[0];
				print "ARGV[1] = " ARGV[1];
				print "ARGV[2] = " ARGV[2];
		}' one two
###ARGC

<<'###NUM-RECORDS' # FNR = record number in file. count is reset for each file

	awk 'BEGIN {FS=","; OFS=","; print "HEADER"}
		 {print FNR, $1, $2}
		 END {print "FOOTER"}' $1 $2
###NUM-RECORDS

<<'###NUM-RECORDS' # NR = record number in file. count is not reset for each file

	awk 'BEGIN {FS=","; OFS=","; print "HEADER"}
		 {print NR, $1, $2}
		 END {print "FOOTER"}' $1 $2
###NUM-RECORDS

<<'###PRINT-LINES' # Using FS and OFS

	awk 'BEGIN {FS=","; OFS="|"; print "HEADER"}
		{print $1, $2}
		END {print "FOOTER"}' $1
###PRINT-LINES

<<'###PRINT-LINES' # Using -F 

	awk -F',' 'BEGIN {OFS="|"; print "HEADER"}
		{print $1, $2}
		END {print "FOOTER"}' $1
###PRINT-LINES

<<'###NUM-FIELDS' # NF - number of fields 

	awk -F',' 'BEGIN {OFS="|"; print "HEADER"}
		(NR==2) {print NF}
		END {print "FOOTER"}' $1
###NUM-FIELDS

<<'###ORS' # ORS - Output Record Separator. Default is \n - newline. 

	awk -F',' 'BEGIN {OFS="|"; ORS="\n"; print "HEADER"}
		{print $1, $2}
		END {print "FOOTER"}' $1
###ORS

<<'###FILENAME' 

	awk -F',' 'BEGIN {OFS="|"; print "HEADER"}
		(NR==2) {print "Awk filename:" FILENAME}
		END {print "FOOTER"}' $1
###FILENAME

#<<'###ENVIRON' # Environment Variables
	awk 'BEGIN {print ENVIRON["USER"] }'
###ENVIRON
