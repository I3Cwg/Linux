#!/bin/bash

<<'###MATCH-PATTERN'

	awk 'BEGIN {FS=",";}
		$0 ~/C[ah]/ {print $2}' $1
###MATCH-PATTERN

<<'###MATCH-NOT-PATTERN'

	awk 'BEGIN {FS=",";}
		$0 !~/C[ah]/ {print $2}' $1
###MATCH-NOT-PATTERN

<<'###MATCH-BEGIN-WITH-PATTERN'

	awk 'BEGIN {FS=",";}
		$2 ~/^T/ {print $2}' $1
###MATCH-BEGIN-WITH-PATTERN

<<'###MATCH-BEGIN-WITH-PATTERN'

	awk 'BEGIN {FS=",";}
		$1 ~/101/ {print $2}' $1
###MATCH-BEGIN-WITH-PATTERN

<<'###MATCH-BEGIN-WITH-A-OR-B-PATTERN'

	awk 'BEGIN {FS=",";}
		$2 ~/^C|^T/ {print $2}' $1
###MATCH-BEGIN-WITH-A-OR-B-PATTERN

<<'###MATCH-ENDING-WITH-PATTERN'

	awk 'BEGIN {FS=",";}
		$0 ~/officer$/ {print $2}' $1
###MATCH-ENDING-WITH-PATTERN

<<'###MATCH-LESS-THAN-PATTERN'

	awk 'BEGIN {FS=",";}
		($1 < 105) {print $1, $2}' $1
###MATCH-LESS-THAN-PATTERN

<<'###MATCH-RECORD#-EQUAL-PATTERN'

	awk 'BEGIN {FS=",";}
		(NR==3 && $0 ~/doctor$/) {print $0}' $1
###MATCH-RECORD#-EQUAL-PATTERN

#<<'###GSUB'
	awk '{gsub(/,/,"-",$0); print $0}' $1
###GSUB
