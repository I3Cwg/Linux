#/bin/bash

# Output to stdout
echo "Output to stdout"

OUTPUT_FILE=./output.txt

# Output piped out to a file using redirection
echo "Redirected output" > ${OUTPUT_FILE}
echo "Appending output" >> ${OUTPUT_FILE}

TEE_FILE=./tee_file.txt

# Output to Stdout as well as file
echo "To stdout plus file " | tee ${TEE_FILE}
echo "Append to stdout plus file " | tee -a ${TEE_FILE}

# Send stdout and stederr to the same file
echo "Just stdout" >> ${OUTPUT_FILE}
lsr >> ${OUTPUT_FILE} 2>&1
