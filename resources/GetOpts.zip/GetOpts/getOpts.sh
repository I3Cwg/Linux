#!/bin/bash

demoUsage() {

	echo -e "Sample Usage: ${0} -a<arg1> -bc<arg2> csvFile txtFile"
	echo -e "\t-a needs an input argument arg1"
	echo -e "\t-b needs no input argument"
	echo -e "\t-c needs an input argument arg2"
	echo -e "\tcsvFile is the name of the input csv file"
	echo -e "\ttxtFile is the name of the input txt file"
}

if [[ "${#}" -ne 0 ]]; then

	x=0

	while getopts ":a:bc:" optName; do
	
		((x++))
		echo "In loop ${x} Optind is ${OPTIND}"
		
		case ${optName} in

			a)
				echo "Optind for a is ${OPTIND}"
				echo "Optarg for a is ${OPTARG}"
				test_val_a=${OPTARG}
				echo "Value of test_val_a: " $test_val_a
			;;
			b)
				echo "Optind for b is ${OPTIND}"
				echo "Optarg for b is ${OPTARG}"
			;;
			c)
				echo "Optind for c is ${OPTIND}"
				echo "Optarg for c is ${OPTARG}"
				test_val_c=${OPTARG}
				echo "Value of test_val_c: " $test_val_c
			;;
			?)
				echo "Option does not match 'a,b or c'"
				echo "Demo usage is: $(demoUsage)"
				exit
			;;
			
		esac
	done

	echo "Before shift 1: ${1}"	
	echo "Before shift 2: ${2}"	
	echo "Before shift 3: ${3}"	
	echo "Before shift 4: ${4}"	
	
	shift $((OPTIND - 1))

	echo "After shift 1: ${1}"
	echo "After shift 2: ${2}"
fi
