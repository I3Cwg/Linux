#!/bin/bash

## Read a file name from the input

	fileName=$1
	echo "Filename: $1"

<<'###FILE-LOOP-1'

	i=0
	echo "#1"
	while read line
	do
		((i++))
		echo "Line#: $i - " $line
	done < ${fileName} | head -10 
###FILE-LOOP-1

<<'###FILE-LOOP-2'

	i=0
	echo "File Loop #2"
	cat ${fileName} | head -10 | while read line
	do
		((i++))
		echo "Line#: $i - " $line
	done   
###FILE-LOOP-2

#<<'###FILE-LOOP-3'

	i=0
	echo "File Loop #3"
	cat ${fileName} | head -10 | while read line
	do
		((i++))
		echo "Line#: $i - " $line
		IFS=,
		for word in $line
		do
			echo "Word: $word"
		done
	done   
###FILE-LOOP-3
