#!/bin/bash

num_array=(1 2 3 4 5)

for x in "${num_array[@]}"
do

	echo "Value of x: $x"

done

echo "**********************"

for (( x = 1; x < 10; x++ ))
do

	if [[ $x -eq 4 ]]; then

	 	continue	
	fi

	echo "x = $x"

done

