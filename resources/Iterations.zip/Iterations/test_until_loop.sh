#!/bin/bash

x=0

echo "Value of x: $x"

until [[ $x -gt 5 ]]
do

	x=$((x + 1))
#	if [[ $x -eq 2 ]]; then
#		continue	
#	fi

	echo "x = $x"

done
