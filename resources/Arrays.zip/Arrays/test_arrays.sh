#!/bin/bash

declare -a test_array=(10 20 30 40)

for element in "${test_array[@]}"
do
	echo "element: $element"
done 

echo "length before adding element: ${#test_array[@]}"

test_array+=(5000)

echo "length after adding element: ${#test_array[@]}"

for index in "${!test_array[@]}"
do
	echo "index: $index and element: ${test_array[index]}"
done 

subset_array=(${test_array[@]:1:3})
echo "********************** subset array output"
for index in "${!subset_array[@]}"
do
	echo "index: $index and element: ${subset_array[index]}"
done 
